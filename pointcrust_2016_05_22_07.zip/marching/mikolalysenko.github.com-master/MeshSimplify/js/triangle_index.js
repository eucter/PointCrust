function TriangleIndex(mesh) {
  
}
