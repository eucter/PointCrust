function MonteCarloSimplification(mesh) {
  return mesh;
}
